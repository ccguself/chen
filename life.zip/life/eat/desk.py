import numpy as np
import pandas as pd

class Desk:
    def __init__(self) -> None:
        pass

    def get_ingredient(self):
        """
            Obtain the data.
        """
        return
    
    def check_ingredient(self):
        """
            Analysis the data, evaluate the feature.
        """
        return
    
    def wash_ingredient(self):
        """
            Get the semi, e.g. features and labels.
        """
        return 

    def cook(self):
        """
            Joint features and labels.
        """
        return 

    def taste_food(self):
        """
        """
        return 
    
    
    