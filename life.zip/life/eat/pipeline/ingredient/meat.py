import ray
import numpy as np
import pandas as pd

class Tick:
    def __init__(self) -> None:
        pass

    def load_data(self):
        return
    
    def process_data(self):
        return 
    
    def get_features(self):
        return
    
    