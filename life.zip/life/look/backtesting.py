"""
    回测主体代码：
    主要用于逐笔行情的回测
"""

class Backtesting:
    def __init__(self) -> None:
        """
        """
        self.depth_snapshot = 5  # 默认恢复的盘口深度
        pass

    def load_data(self):
        return
    
    def run_backtesting(self):
        # 逐步循环，回放逐笔委托数据
        
        # 根据撮合规则，生成盘口数据

        # 根据撮合规则，生成逐笔成交数据

        return
    
